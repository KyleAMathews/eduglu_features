// Global killswitch: only run if we are in a supported browser.
if (Drupal.jsEnabled) {

